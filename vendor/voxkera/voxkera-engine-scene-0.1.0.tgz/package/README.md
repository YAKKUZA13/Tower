# @voxkera/engine-scene

ESM package. Import from `@voxkera/engine-scene`; TypeScript declarations ship in dist. No source subpaths are exported.

Renderer-independent; no Babylon, Vue, Tower or browser globals required.

Private extraction, UNLICENSED. Build from the monorepo root with npm run build.
