# @voxkera/voxel-core

ESM package. Import from `@voxkera/voxel-core`; TypeScript declarations ship in dist. No source subpaths are exported.

Renderer-independent; no Babylon, Vue, Tower or browser globals required.

Private extraction, UNLICENSED. Build from the monorepo root with npm run build.
