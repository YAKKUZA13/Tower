# @voxkera/voxel-babylon

ESM package. Import from `@voxkera/voxel-babylon`; TypeScript declarations ship in dist. No source subpaths are exported.

Requires the application to provide @babylonjs/core 7.54.3. Babylon is a peer, not bundled.

Private extraction, UNLICENSED. Build from the monorepo root with npm run build.

TypeScript: use Bundler module resolution. With TypeScript 6, skipLibCheck is required for Babylon 7.54.3 declarations. See ../../docs/typescript-compatibility.md.
