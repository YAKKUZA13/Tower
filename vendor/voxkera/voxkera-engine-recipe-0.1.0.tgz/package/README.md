# @voxkera/engine-recipe

ESM package. Import from `@voxkera/engine-recipe`; TypeScript declarations ship in dist. No source subpaths are exported.

Renderer-independent; no Babylon, Vue, Tower or browser globals required.

Private extraction, UNLICENSED. Build from the monorepo root with npm run build.
