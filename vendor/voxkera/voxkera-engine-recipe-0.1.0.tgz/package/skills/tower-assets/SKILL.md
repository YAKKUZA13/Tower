---
name: tower-assets
description: Author and validate runtime-generated articulated voxel characters, creatures and equipment for the Tower engine using its JSON asset contract and public APIs. Use for asset creation and animation/socket review, not for implementing gameplay or importing premade models.
---

# Tower runtime assets

Produce data, not a bespoke character renderer. Use the installed engine's
`characterRecipeJsonSchema()` and [contract/API notes](references/contract.md).
The [starter](assets/starter.json) is executable input, not a mandatory anatomy.

## Workflow

1. Establish the intended silhouette, game-scale readability and motion. If using
   an image, separate observed features from assumptions about hidden sides.
2. Enumerate named articulated parts, their pivots and equipment/effect sockets.
   Define critical visual features and review views in the recipe's `quality` block.
3. Author `kind: character`, `formatVersion: 1` JSON. Use supported box/ellipsoid
   shapes and a small palette; keep moving parts separate. Do not paste thousands
   of raw voxels or introduce per-character TypeScript builders.
4. Validate structure **and semantics** through `loadCharacterRecipe`, then run
   `compileCharacterAsset`. Return the exact issue path/code when rejected.
   JSON Schema alone cannot check graph cycles, references or cumulative budgets.
5. Preview through `createCharacterAssetTemplate` and its instance handles. Use
   one template for a family, not one template per spawned actor. Inspect named
   parts/sockets, the rest pose, clip endpoints and transitions.
6. Review front, side, back and a nondegenerate orbit view at the intended game
   resolution. Inspect attachments during motion, not just in the rest pose.
   Exploded inspection is structural evidence, not a physical animation state.
7. Report structural validation and visual approval separately, with screenshot
   paths, remaining limitations and the next correction. Stop after repeated
   non-improving corrections and explain the missing input/capability.

## Non-obvious invariants

- X-right, Y-up, +Z character-forward. Voxel centres are integers; box min/max
  include both endpoints. Pivots, geometry and socket positions are **absolute
  model-grid coordinates**, not parent-local coordinates. Parent declaration order
  does not matter. There is exactly one root and no hierarchy cycle.
- Animation time is seconds. Rotation tuples are `[X,Y,Z]` **radians** with YXZ
  composition (Babylon yaw/pitch/roll), relative to rest. No degree conversion is
  implicit. Linear Euler interpolation is component-wise, not shortest-arc slerp.
- Color IDs resolve in `palette`. Optional `surface` owns emission/specular
  independently from albedo. Do not make the whole body emissive to brighten eyes.
- Clip events are time-ordered `{id,time}` notifications. Damage/cooldowns remain
  game logic. Seeking a preview does not replay action events. Never infer hits
  from a renderer's pose or Tower's cooldown implementation.
- Budget the sampled shape cells, **whole per-part meshing AABBs**, and generated
  voxels. Sparse distant shapes can be expensive even with few occupied cells.
  Tighten budgets when needed; do not raise host ceilings to hide bad geometry.
- Normalized rigs are height 1 with base Y=-0.5. Root transforms place them in the
  world. `attach(socket, child.root, scale, childGripSocket)` aligns the grip;
  scale is measured in the parent's model-grid units. The attached child is then
  disposed with that hierarchy unless detached.
- Closing a template forbids new instances but preserves existing ones. Dispose
  every instance and template. Do not edit shared geometry/materials to change
  just one instance's appearance.

Unknown fields/capabilities fail. Do not silently emulate rest rotations, IK,
skinning, morphs, arbitrary CSG, external model URLs or executable expressions.
If the requested asset needs those, report the limitation instead of changing the
engine or inventing accepted JSON fields.

## Deliverable

Recipe JSON, structural/compile result, rendered review evidence, supported clips
and sockets, and explicit remaining limitations. A script passing is not a visual
similarity score and does not establish mobile performance.
