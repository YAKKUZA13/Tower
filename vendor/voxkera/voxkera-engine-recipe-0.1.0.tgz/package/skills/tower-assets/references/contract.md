# Portable contract and public API

Use the version installed by the consuming project. All packages remain private
until release/license approval; local tarball installation is supported.

```ts
import { loadCharacterRecipe, characterRecipeJsonSchema } from '@voxkera/engine-recipe';
import { compileCharacterAsset } from '@voxkera/voxel-core';
import { createCharacterAssetTemplate } from '@voxkera/voxel-babylon';

const loaded = loadCharacterRecipe(jsonText);
if (!loaded.ok) throw new Error(JSON.stringify(loaded.errors));
const compiled = compileCharacterAsset(loaded.recipe);
if (!compiled.ok) throw new Error(JSON.stringify(compiled.errors));
const template = createCharacterAssetTemplate(scene, compiled.asset);
const actor = template.instantiate();
actor.play(compiled.asset.recipe.clips[0].id, { fadeSeconds: 0.15 });
const events = actor.advance(1 / 60);
// Events: started / marker / interrupted / completed. No side effects are applied.
actor.stop(); // rest pose
actor.dispose(); template.dispose();
```

Assets without clips, including equipment, are valid: do not call play on them.
`actor.parts` and `actor.sockets` are readonly maps of Babylon transform nodes.
`actor.sampleClip(id, seconds)` is a preview seek with no event replay.
`actor.attach(socketId, child.root, modelScale, child.sockets.get('grip'))` returns
a detach callback. Part IDs and socket IDs need not be humanoid joint names.

Get the complete current structural schema with:

```sh
node --input-type=module -e "import {characterRecipeJsonSchema} from '@voxkera/engine-recipe'; console.log(JSON.stringify(characterRecipeJsonSchema(),null,2))"
```

In the Tower checkout, run `npm run smoke:assets`, then `npm run dev:lab` and open
`http://127.0.0.1:5184/#character`. The lab offers humanoid, nonhumanoid and equipment
fixtures, named-part picking, socket inspection, grip alignment, exploded views,
manual seeks, fades/events and four review cameras. Select WebGPU explicitly with
`?backend=webgpu#character`; check the **selected**, not just requested, backend.

Root object fields: `formatVersion`, `kind`, `id`, `palette`, `parts`, `sockets`,
`clips`, `budget`, `quality`. Unknown keys are errors. Optional surface properties:
`emissive: [r,g,b]`, `emissiveStrength: 0..4`, `specular?: [r,g,b]`.
Clip duration is 0.001..60 seconds. Events may share a timestamp but must be ordered.
Transitions freeze the outgoing displayed pose and fade toward the advancing new
clip; interruption captures the current displayed blend. This is not a live
two-clip crossfade, IK, or root motion. At most 1024 events per advance by default;
overflow fails before clock/state advancement instead of dropping markers.
